package org.ansj.demo;

import org.ansj.util.WordAlert;

/**
 * 句子标准化demo
 * @author ansj
 *
 */
public class SentenceCover {
	public static void main(String[] args) {
		System.out.println(WordAlert.alertStr("ａ ｚ Ａ Ｚ A Z  a z 0 ９ 0 9 ？ 『  ﹩"));
	}
}
