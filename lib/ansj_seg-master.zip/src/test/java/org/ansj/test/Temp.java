package org.ansj.test;

public class Temp {
	public static void main(String[] args) {
		for (int i = '0'; i <= '9'; i++) {
			System.out.println((char) i);
		}
		for (int i = '0'; i <= '９'; i++) {
			System.out.println((char) i);
		}


		for (int i = 'a'; i <= 'z'; i++) {
			System.out.println((char) i);
		}
		
		for (int i = 'ａ'; i <= 'ｚ'; i++) {
			System.out.println((char) i);
		}
		
		for (int i = 'Ａ'; i <= 'Ｚ'; i++) {
			System.out.println((char) i);
		}
		
		for (int i = 'A'; i <= 'Z'; i++) {
			System.out.println((char) i);
		}
	}
}
